package com.app.final_kumar_shubham.data.remote

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

/**
 * @author Kumar Shubham
 * 10/1/20
 */
class FirebaseHandler {


    companion object {
        val DB = FirebaseDatabase.getInstance()
        var uid = FirebaseAuth.getInstance().uid
    }

    private val mFireBaseAuth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }

    //get database refrence
    fun getUserReference(): DatabaseReference {
        return DB.getReference("users")
    }

    //get instance of current user
    fun currentUser() = mFireBaseAuth.currentUser


    //get Current User Id
    private fun getUserId():String{
        return mFireBaseAuth.currentUser?.uid.toString()
    }

    // logout user
    fun makeSignOut() {
        mFireBaseAuth.signOut()
    }

    //Check Login
    fun isLoggedIn(): Boolean {
        return mFireBaseAuth.currentUser != null
    }

   
}