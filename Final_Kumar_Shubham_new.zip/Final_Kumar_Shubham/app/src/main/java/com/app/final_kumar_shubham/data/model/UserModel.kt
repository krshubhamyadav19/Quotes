package com.app.final_kumar_shubham.data.model

/**
 * @author Kumar Shubham
 * 17/12/19
 */
class UserModel(var quotes: String = "", var email: String = "")