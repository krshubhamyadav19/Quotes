package com.app.final_kumar_shubham.authentication.createacount

/**
 * @author Kumar Shubham
 * 17/12/19
 */
class UserCreateAcountModel(var uid:String="", var username:String="", var dob:String=""){
}